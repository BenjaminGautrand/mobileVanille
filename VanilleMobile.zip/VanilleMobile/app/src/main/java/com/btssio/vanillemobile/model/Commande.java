package com.btssio.vanillemobile.model;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;


public final class Commande {

    private static Commande instance = null;
    private int id;
    private Long dateCommande;
    public Client leClient;
    private HashMap<Produit, Integer> lignesCommande = new HashMap<Produit, Integer>() ;

    public Long getDateCommande() {
        return dateCommande;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "id=" + id +
                ", dateCommande=" + dateCommande +
                ", leClient=" + leClient +
                ", lignesCommande=" + lignesCommande +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Client getLeClient() {
        return leClient;
    }

    public void setLeClient(Client leClient) {
        this.leClient = leClient;
    }

    public HashMap<Produit, Integer> getLignesCommande() {
        return lignesCommande;
    }

    public void setLignesCommande(HashMap<Produit, Integer> lignesCommande) {
        this.lignesCommande = lignesCommande;
    }

    private Commande(Long dateCommande) {

        this.dateCommande = dateCommande;

        //création d'une catégorie
        Categorie bonbons = new Categorie("bon","bonbons");
        //ajout de lignes à la commande
        lignesCommande.put(new Produit("B004","Bonbons caramel Lot 4 Kg","",(float)5.0,bonbons),10);
        lignesCommande.put(new Produit("B005","Bonbons acidulés Lot 5 Kg","",(float)1.0,bonbons),2);
    }
    /*
    public float getTotalCommande(){
        float total = (float) 0.0;
        for(Map.Entry<Produit,Integer> entry : lignesCommande.entrySet()) {
            total += (float) (entry.getValue() * (entry.getKey().getPrixActuel(LocalDate.now())));
        }
        return total;
    }*/

    public String getTotalCommande(){
        float total = (float) 0.0;
        for(Map.Entry<Produit,Integer> entry : lignesCommande.entrySet()) {
            total += (float) (entry.getValue() * (entry.getKey().getPrixActuel(LocalDate.now())));
        }
        String totalStr = String.valueOf(total);
        return totalStr;
    }

    public final static Commande getInstance(){
        if(Commande.instance == null){
            synchronized(Commande.class){
                if(Commande.instance == null){
                    Commande.instance = new Commande(new java.util.Date().getTime());
                }
            }
        }
        return Commande.instance;
    }
}