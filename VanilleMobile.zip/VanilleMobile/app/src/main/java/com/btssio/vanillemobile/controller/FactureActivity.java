package com.btssio.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.btssio.vanillemobile.R;
import com.btssio.vanillemobile.model.Client;
import com.btssio.vanillemobile.model.Commande;
import com.btssio.vanillemobile.outils.Serializer;
import com.btssio.vanillemobile.repository.ClientRepository;

public class FactureActivity extends AppCompatActivity {

    private EditText editNom;
    private EditText editPrenom;
    private EditText editAdresse;
    private EditText editCP;
    private EditText editVille;
    private EditText editMail;

    private TextView txtMontant;
    private TextView txtTotal;
    private TextView txteuros;
    private TextView txtMail;
    private TextView txtPrenom;
    private TextView txtNom;
    private TextView txtAdresse;
    private TextView txtCP;
    private TextView txtVille;

    private Button btEnvoyer;
    private Button bt_modifier;
    private Button btAnnuler;

    private Commande commandeEnCours;

    private void init(){
        editAdresse = findViewById(R.id.editAdresse);
        editCP = findViewById(R.id.editCP);
        editMail = findViewById(R.id.editMail);
        editNom = findViewById(R.id.editNom);
        editPrenom = findViewById(R.id.editPrenom);
        editVille = findViewById(R.id.editVille);
        txtMontant = findViewById(R.id.txtMontant);
        btEnvoyer= findViewById(R.id.btEnvoyer);
        //txtMontant.setText("100.20");
        commandeEnCours = Commande.getInstance();
        txtMontant.setText(commandeEnCours.getTotalCommande());

        final Context context = this;
        recupClient();

        btEnvoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Création d'un client
                Client client = new Client(editNom.getText().toString(), editPrenom.getText().toString(), editAdresse.getText().toString(), editCP.getText().toString(), editVille.getText().toString(), editMail.getText().toString());

                //Ajout du client à la commande
                commandeEnCours.leClient = client;

                Toast.makeText(view.getContext(), "Votre commande d'un montant de " +txtMontant.getText()+
                        " a bien été envoyée ! Vous recevrez un mail de confirmation à l'adresse mail suivante : "+editMail.getText().toString(), Toast.LENGTH_SHORT).show();
                Log.i("envoyer","onClick "+ commandeEnCours.getLeClient().toString());
            }
        });
    }

    private void recupClient(){
        if (null != Serializer.deSerialize(ClientRepository.getNomFichier(), this)){
            Client leClient = (Client)Serializer.deSerialize(ClientRepository.getNomFichier(), this);
            editNom.setText(leClient.getNomClient());
            editPrenom.setText(leClient.getPrenom());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facture);
        init();
    }

}