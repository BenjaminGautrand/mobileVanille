package com.btssio.vanillemobile.model;

import java.io.Serializable;

public class Client implements Serializable {

    private String nomClient;
    private String prenom;
    private String adresse;
    private String cpClient;
    private String villeClient;
    private String mailClient;

    /**
     *
     * @param nomClient
     * @param prenom
     * @param adresse
     * @param cpClient
     * @param villeClient
     * @param mailClient
     */
    public Client(String nomClient, String prenom, String adresse, String cpClient, String villeClient, String mailClient) {
        this.nomClient = nomClient;
        this.prenom = prenom;
        this.adresse = adresse;
        this.cpClient = cpClient;
        this.villeClient = villeClient;
        this.mailClient = mailClient;
    }

    public String getNomClient() {
        return nomClient;
    }

    public void setNomClient(String nomClient) {
        this.nomClient = nomClient;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getCpClient() {
        return cpClient;
    }

    public void setCpClient(String cpClient) {
        this.cpClient = cpClient;
    }

    public String getVilleClient() {
        return villeClient;
    }

    public void setVilleClient(String villeClient) {
        this.villeClient = villeClient;
    }

    public String getMailClient() {
        return mailClient;
    }

    public void setMailClient(String mailClient) {
        this.mailClient = mailClient;
    }

    @Override
    public String toString() {
        return "Client{" +
                "nomClient='" + nomClient + '\'' +
                ", prenom='" + prenom + '\'' +
                ", adresse='" + adresse + '\'' +
                ", cpClient='" + cpClient + '\'' +
                ", villeClient='" + villeClient + '\'' +
                ", mailClient='" + mailClient + '\'' +
                '}';
    }


}
