package com.btssio.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.btssio.vanillemobile.R;
import com.btssio.vanillemobile.model.Categorie;
import com.btssio.vanillemobile.model.Commande;
import com.btssio.vanillemobile.model.Produit;

import java.time.LocalDate;

public class ProduitActivity extends AppCompatActivity {

    private TextView txtTitre;
    private TextView txtQuantite;
    private TextView txtPU;
    private TextView txtAffichePU;
    private TextView txtTotal2;
    private TextView txtAfficheTotal;

    private EditText editQuantite;

    private Button btCalculer;
    private Button btAjouter;

    private Commande commandeEnCours;
    private Produit produitSelectionne;

    private void init(){
        editQuantite = findViewById(R.id.editQuantite);
        txtTitre = findViewById(R.id.txtTitre);
        txtAffichePU = findViewById(R.id.txtAffichePU);
        txtAfficheTotal = findViewById(R.id.txtAfficheTotal);
        btAjouter = findViewById(R.id.btAjouter);
        btCalculer = findViewById(R.id.btCalculer);

        commandeEnCours = Commande.getInstance();

        Categorie chocolats = new Categorie("cho", "Chocolats");
        produitSelectionne = new Produit("B003", "Bonbons chocolat Lot 3kg", "", (float)3.0,chocolats);

        txtAffichePU.setText(String.valueOf(produitSelectionne.getPrixActuel(LocalDate.now())));

        btCalculer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int qte;
                float prix;
                qte = Integer.parseInt(editQuantite.getText().toString());
                prix = Float.parseFloat(txtAffichePU.getText().toString());
                txtAfficheTotal.setText(String.valueOf(qte*prix));
            }
        });

        btAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int qte = Integer.parseInt(editQuantite.getText().toString());

                Log.i("ajouter", "onClick: ");
                Log.i("ajouter", instance.getCommande().toString());
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produit);
        init();
    }

}